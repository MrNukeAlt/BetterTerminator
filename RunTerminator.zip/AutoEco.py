import tkinter as tk
from tkinter import ttk
import keyboard
import threading
import time
import pydirectinput

# Disable failsafe to prevent movement if mouse hits corner
pydirectinput.FAILSAFE = False

# --- Data ---
data_rows = [
    ('1', 'RedGroup1', 'Grouped Reds'), ('2', 'BlueGroup1', 'Blue Bloon'),
    ('3', 'GreenGroup1', 'Grouped Greens'), ('4', 'YellowGroup1', 'Grouped Yellows'),
    ('5', 'PinkGroup1', 'Grouped Pink'), ('6', 'WhiteGroup1', 'White Bloon'),
    ('7', 'BlackGroup1', 'Black Bloon'), ('8', 'ZebraGroup1', 'Zebra Bloon'),
    ('9', 'LeadGroup1', 'Grouped Leads'), ('0', 'CeremicGroup1', 'Fast Ceremic'),
    ('o', 'MOABGroup1', 'Fast MOAB'), ('p', 'FastBFBGroup1', 'Fast BFB'),
    ('shift+1', 'SpaceBlue1', 'Blue Bloon'), ('shift+2', 'PinkGroup1', 'Spaced Pink'),
    ('shift+3', 'SpacedBlack1', 'Spaced Black'), ('shift+4', 'SpaceWhite1', 'Spaced White'),
    ('shift+5', 'SpaceLead1', 'Spaced Leads'), ('shift+6', 'SpaceZebra1', 'Space Zebra'),
    ('shift+7', 'SpaceRainbowGroup1', 'Space Rainbow'), ('shift+8', 'RainbowGroup1', 'Rainbow Bloon'),
    ('shift+9', 'SpaceCeremic1', 'Space Ceremic'), ('shift+0', 'SpaceMOABGroup1', 'Space MOAB'),
    ('shift+o', 'BFBGroup1', 'BFB'), ('shift+p', 'ZOMGGroup1', 'ZOMG')
]

class AutoSenderGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Bloon Auto-Sender")
        self.root.geometry("400x500")
        
        self.enabled = False
        self.current_key = None # The key to press
        self.visible = True

        self.status_label = tk.Label(root, text="Status: DISABLED", fg="red", font=("Arial", 12, "bold"))
        self.status_label.pack(pady=10)
        
        self.target_label = tk.Label(root, text="Selected: None")
        self.target_label.pack()

        # Treeview
        self.tree = ttk.Treeview(root, columns=('Key', 'ID', 'Desc'), show='headings')
        for col in ('Key', 'ID', 'Desc'):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=80)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        for row in data_rows:
            self.tree.insert('', tk.END, values=row)

        # Hotkeys
        keyboard.add_hotkey('f2', self.toggle_visibility)
        keyboard.add_hotkey('f4', self.toggle_enabled)
        
        for row in data_rows:
            key = row[0]
            keyboard.add_hotkey(key, lambda k=key: self.set_target(k))

    def set_target(self, key):
        self.current_key = key
        self.target_label.config(text=f"Selected: {key}")

    def toggle_enabled(self):
        self.enabled = not self.enabled
        state_text = "ENABLED" if self.enabled else "DISABLED"
        color = "green" if self.enabled else "red"
        self.status_label.config(text=f"Status: {state_text}", fg=color)

    def toggle_visibility(self):
        self.visible = not self.visible
        self.root.withdraw() if not self.visible else self.root.deiconify()

# Simulated keypress logic
def send_key(key):
    if '+' in key:
        # Handle combinations like shift+1
        parts = key.split('+')
        modifier, actual_key = parts[0], parts[1]
        pydirectinput.keyDown(modifier)
        pydirectinput.press(actual_key)
        pydirectinput.keyUp(modifier)
    else:
        pydirectinput.press(key)

def run_sender(app):
    while True:
        if app.enabled and app.current_key:
            send_key(app.current_key)
            time.sleep(1) # Adjust speed here
        time.sleep(0.1)

if __name__ == "__main__":
    root = tk.Tk()
    app = AutoSenderGUI(root)
    
    thread = threading.Thread(target=run_sender, args=(app,), daemon=True)
    thread.start()
    
    root.mainloop()