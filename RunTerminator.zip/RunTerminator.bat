@echo off
:: Change the directory to where this .bat file is located
cd /d "%~dp0"

echo Launching Bloons Terminator...

:: Start the overlay in the background
:: (We use 'start' so it doesn't block the main script from running)
start "" python bloonsClientOverlay.py

:: Run the main client in the foreground
python bloonsClient.py

:: Keep the window open so you can see errors if the script crashes
pause