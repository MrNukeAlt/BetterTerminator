import tkinter as tk
import keyboard
import ctypes
import sys
import win32gui
import win32process
import psutil

def run_as_admin():
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit()
    except: sys.exit()

run_as_admin()

def is_game_focused():
    """
    Checks if the currently active (focused) window belongs to Ninja Kiwi Archive.
    """
    try:
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        process_name = psutil.Process(pid).name()
        return process_name.lower() == "ninja kiwi archive.exe".lower()
    except Exception:
        return False

class Overlay(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bloons Terminator HUD")
        self.attributes("-topmost", True)
        self.overrideredirect(True)
        self.attributes("-alpha", 0.9)
        self.configure(bg="black")
        
        # Geometry tracking variables
        self.current_width = 300
        self.current_height = 570
        self.offset_x = 0
        self.offset_y = 0
        self.first_track = True
        self.is_interacting = False  # Prevents loop stuttering while dragging/resizing
        
        self.geometry(f"{self.current_width}x{self.current_height}+50+50") 
        self.withdraw()
        
        self.hud_enabled = True  
        self.auto_round_status = False
        self.regen_status = False
        self.camo_status = False
        
        # Main HUD label
        self.label = tk.Label(self, text="...", fg="lime", bg="black", font=("Consolas", 8), justify="left")
        self.label.pack(fill="both", expand=True, padx=5, pady=5)
        self.update_ui_text()
        
        # Custom Drag Bindings (Click anywhere on the text to move)
        self.label.bind("<Button-1>", self.start_drag)
        self.label.bind("<B1-Motion>", self.drag)
        self.label.bind("<ButtonRelease-1>", self.stop_interaction)
        
        # Custom Resize Handle (Small square in the bottom right corner)
        self.resize_handle = tk.Frame(self, bg="lime", width=12, height=12, cursor="size_nw_se")
        self.resize_handle.place(relx=1.0, rely=1.0, anchor="se")
        self.resize_handle.bind("<Button-1>", self.start_resize)
        self.resize_handle.bind("<B1-Motion>", self.resize)
        self.resize_handle.bind("<ButtonRelease-1>", self.stop_interaction)
        
        # Thread-safe hotkey bindings
        keyboard.add_hotkey("f1", lambda: self.after_idle(self.toggle_hud))
        keyboard.add_hotkey("down", lambda: self.after_idle(self.toggle_auto_round))
        keyboard.add_hotkey("left", lambda: self.after_idle(self.toggle_camo))
        keyboard.add_hotkey("right", lambda: self.after_idle(self.toggle_regen))
        
        self.update_position()

    # --- Window Movement Logic ---
    def start_drag(self, event):
        self.is_interacting = True
        self.drag_start_x = event.x_root
        self.drag_start_y = event.y_root
        self.window_start_x = self.winfo_x()
        self.window_start_y = self.winfo_y()

    def drag(self, event):
        delta_x = event.x_root - self.drag_start_x
        delta_y = event.y_root - self.drag_start_y
        new_x = self.window_start_x + delta_x
        new_y = self.window_start_y + delta_y
        
        # Recalculate offset relative to game window dynamically while dragging
        hwnd = win32gui.FindWindow(None, "Bloons TD Battles")
        if hwnd:
            rect = win32gui.GetWindowRect(hwnd)
            self.offset_x = new_x - rect[0]
            self.offset_y = new_y - rect[1]
            
        self.geometry(f"{self.current_width}x{self.current_height}+{new_x}+{new_y}")

    # --- Window Resize Logic ---
    def start_resize(self, event):
        self.is_interacting = True
        self.resize_start_x = event.x_root
        self.resize_start_y = event.y_root
        self.window_start_width = self.winfo_width()
        self.window_start_height = self.winfo_height()

    def resize(self, event):
        delta_x = event.x_root - self.resize_start_x
        delta_y = event.y_root - self.resize_start_y
        
        # Maintain a safe minimum sizing window constraint
        self.current_width = max(200, self.window_start_width + delta_x)
        self.current_height = max(300, self.window_start_height + delta_y)
        
        self.geometry(f"{self.current_width}x{self.current_height}+{self.winfo_x()}+{self.winfo_y()}")

    def stop_interaction(self, event):
        self.is_interacting = False

    # --- Gameplay Functions ---
    def toggle_hud(self):
        self.hud_enabled = not self.hud_enabled
        self.update_position()

    def toggle_auto_round(self):
        if not is_game_focused():
            return
        self.auto_round_status = not self.auto_round_status
        self.update_ui_text()
        
    def toggle_camo(self):
        if not is_game_focused():
            return
        self.camo_status = not self.camo_status
        self.update_ui_text()

    def toggle_regen(self):
        if not is_game_focused():
            return
        self.regen_status = not self.regen_status
        self.update_ui_text()

    def update_ui_text(self):
        auto_status = "ENABLED" if self.auto_round_status else "DISABLED"
        camo = "ON" if self.camo_status else "OFF"
        regen = "ON" if self.regen_status else "OFF"
        
        ui_text = "--- BLOONS TERMINATOR HUD ---\n"
        ui_text += f"Auto-Round: {auto_status}\n"
        ui_text += f"Camo: {camo} | Regen: {regen}\n\n"
        ui_text += "F1: Toggle HUD | UP: Start Round\n"
        ui_text += "DOWN: Toggle Auto-Round\n"
        ui_text += "LEFT: Toggle Camo | RIGHT: Toggle Regen\n\n"
        ui_text += "BLOON SEND HOTKEYS (Shift + Key):\n"
        
        bloons = ["Red", "BlueSpaced", "BlueGrouped", "Green", "Yellow", "PinkSpaced", "PinkGrouped", "BlackSpaced", "BlackGrouped", "WhiteSpaced", "WhiteGrouped", "LeadSpaced", "LeadGrouped", "ZebraSpaced", "ZebraGrouped", "RainbowSpaced", "RainbowGrouped", "Ceramic", "MOAB", "BFB", "ZOMG"]
        for i, b in enumerate(bloons):
            ui_text += f"Shift+{chr(97 + i)}: {b}\n"
            
        self.label.config(text=ui_text)

    def update_position(self):
        hwnd = win32gui.FindWindow(None, "Bloons TD Battles")
        if hwnd:
            rect = win32gui.GetWindowRect(hwnd)
            
            # Snap flat to the game window top-left corner on first boot
            if self.first_track:
                self.offset_x = 0
                self.offset_y = 0
                self.first_track = False
            
            # Apply geometry updates smoothly, skipping frames while user manual edits are happening
            if not self.is_interacting:
                target_x = rect[0] + self.offset_x
                target_y = rect[1] + self.offset_y
                self.geometry(f"{self.current_width}x{self.current_height}+{target_x}+{target_y}")
            
            if self.hud_enabled:
                if not self.winfo_ismapped():
                    self.deiconify()
            else:
                if self.winfo_ismapped():
                    self.withdraw()
        else:
            self.first_track = True  # Reset position alignment rules if game gets closed
            if self.winfo_ismapped():
                self.withdraw()
            
        self.after(500, self.update_position)

if __name__ == "__main__":
    app = Overlay()
    app.mainloop()