import tkinter as tk
import keyboard
import ctypes
import sys
import win32gui
import win32process
import psutil

def run_as_admin():
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit()
    except: sys.exit()

run_as_admin()

def is_game_focused():
    """
    Checks if the currently active (focused) window belongs to Ninja Kiwi Archive.
    """
    try:
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        process_name = psutil.Process(pid).name()
        return process_name.lower() == "ninja kiwi archive.exe".lower()
    except Exception:
        return False

class Overlay(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bloons Terminator HUD")
        self.attributes("-topmost", True)
        self.overrideredirect(True)
        self.attributes("-alpha", 0.9)
        self.configure(bg="black")
        self.geometry("300x570+50+50") # Slightly increased height to accommodate new text
        
        # Start hidden until the window is found for the first time
        self.withdraw()
        
        self.auto_round_status = False
        self.regen_status = False
        self.camo_status = False
        
        self.label = tk.Label(self, text="...", fg="lime", bg="black", font=("Consolas", 8), justify="left")
        self.label.pack(fill="both", expand=True, padx=5, pady=5)
        self.update_ui_text()
        
        keyboard.add_hotkey("f1", lambda: self.withdraw() if self.winfo_ismapped() else self.deiconify())
        keyboard.add_hotkey("down", self.toggle_auto_round)
        keyboard.add_hotkey("left", self.toggle_camo)
        keyboard.add_hotkey("right", self.toggle_regen)
        
        self.update_position()

    def toggle_auto_round(self):
        if not is_game_focused():
            return
        self.auto_round_status = not self.auto_round_status
        self.update_ui_text()
        
    def toggle_camo(self):
        if not is_game_focused():
            return
        self.camo_status = not self.camo_status
        self.update_ui_text()

    def toggle_regen(self):
        if not is_game_focused():
            return
        self.regen_status = not self.regen_status
        self.update_ui_text()

    def update_ui_text(self):
        auto_status = "ENABLED" if self.auto_round_status else "DISABLED"
        camo = "ON" if self.camo_status else "OFF"
        regen = "ON" if self.regen_status else "OFF"
        
        ui_text = "--- BLOONS TERMINATOR HUD ---\n"
        ui_text += f"Auto-Round: {auto_status}\n"
        ui_text += f"Camo: {camo} | Regen: {regen}\n\n"
        ui_text += "F1: Toggle HUD | UP: Start Round\n"
        ui_text += "DOWN: Toggle Auto-Round\n"
        ui_text += "LEFT: Toggle Camo | RIGHT: Toggle Regen\n\n"
        ui_text += "BLOON SEND HOTKEYS (Shift + Key):\n"
        
        bloons = ["Red", "BlueSpaced", "BlueGrouped", "Green", "Yellow", "PinkSpaced", "PinkGrouped", "BlackSpaced", "BlackGrouped", "WhiteSpaced", "WhiteGrouped", "LeadSpaced", "LeadGrouped", "ZebraSpaced", "ZebraGrouped", "RainbowSpaced", "RainbowGrouped", "Ceramic", "MOAB", "BFB", "ZOMG"]
        for i, b in enumerate(bloons):
            ui_text += f"Shift+{chr(97 + i)}: {b}\n"
            
        self.label.config(text=ui_text)

    def update_position(self):
        hwnd = win32gui.FindWindow(None, "Bloons TD Battles")
        if hwnd:
            rect = win32gui.GetWindowRect(hwnd)
            self.geometry(f"300x570+{rect[0]}+{rect[1]}")
            
            # Show the overlay if it's currently hidden and game is found
            if not self.winfo_ismapped():
                self.deiconify()
        else:
            # Hide the overlay if the game window is not found
            self.withdraw()
            
        self.after(500, self.update_position)

if __name__ == "__main__":
    app = Overlay()
    app.mainloop()