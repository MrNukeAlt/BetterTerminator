import tkinter as tk
import keyboard
import ctypes
import sys
import win32gui
import win32process
import psutil

def run_as_admin():
    try:
        if not ctypes.windll.shell32.IsUserAnAdmin():
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            sys.exit()
    except: sys.exit()

run_as_admin()

def is_game_focused():
    """
    Checks if the currently active (focused) window belongs to Ninja Kiwi Archive.
    """
    try:
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        process_name = psutil.Process(pid).name()
        return process_name.lower() == "ninja kiwi archive.exe".lower()
    except Exception:
        return False

class Overlay(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Bloons Terminator HUD")
        self.attributes("-topmost", True)
        self.overrideredirect(True)
        self.attributes("-alpha", 0.9)
        self.configure(bg="black")
        
        # Geometry tracking variables
        self.current_width = 300
        self.current_height = 680  
        self.offset_x = 0
        self.offset_y = 0
        self.first_track = True
        self.is_interacting = False  # Prevents loop stuttering while dragging/resizing
        
        self.geometry(f"{self.current_width}x{self.current_height}+50+50") 
        self.withdraw()
        
        self.hud_enabled = True  
        self.auto_round_status = False
        self.regen_status = False
        self.camo_status = False
        self.auto_send_status = False  
        self.last_bloon = "None"      
        
        # Main HUD label
        self.label = tk.Label(self, text="...", fg="lime", bg="black", font=("Consolas", 8), justify="left")
        self.label.pack(fill="both", expand=True, padx=5, pady=5)
        self.update_ui_text()
        
        # Custom Drag Bindings (Click anywhere on the text to move)
        self.label.bind("<Button-1>", self.start_drag)
        self.label.bind("<B1-Motion>", self.drag)
        self.label.bind("<ButtonRelease-1>", self.stop_interaction)
        
        # Custom Resize Handle (Small square in the bottom right corner)
        self.resize_handle = tk.Frame(self, bg="lime", width=12, height=12, cursor="size_nw_se")
        self.resize_handle.place(relx=1.0, rely=1.0, anchor="se")
        self.resize_handle.bind("<Button-1>", self.start_resize)
        self.resize_handle.bind("<B1-Motion>", self.resize)
        self.resize_handle.bind("<ButtonRelease-1>", self.stop_interaction)
        
        # Thread-safe hotkey bindings
        keyboard.add_hotkey("f1", lambda: self.after_idle(self.toggle_hud))
        keyboard.add_hotkey("down", lambda: self.after_idle(self.toggle_auto_round))
        keyboard.add_hotkey("left", lambda: self.after_idle(self.toggle_camo))
        keyboard.add_hotkey("right", lambda: self.after_idle(self.toggle_regen))
        keyboard.add_hotkey("ctrl+space", lambda: self.after_idle(self.toggle_auto_send))
        keyboard.add_hotkey("shift+space", lambda: self.after_idle(self.trigger_last_bloon))
        
        # Hook manual selections to synchronize overlay tracking
        bloons = ["Red", "BlueSpaced", "BlueGrouped", "Green", "Yellow", "PinkSpaced", "PinkGrouped", "BlackSpaced", "BlackGrouped", "WhiteSpaced", "WhiteGrouped", "LeadSpaced", "LeadGrouped", "ZebraSpaced", "ZebraGrouped", "RainbowSpaced", "RainbowGrouped", "Ceramic", "MOAB", "BFB", "ZOMG"]
        for i, b in enumerate(bloons):
            key_combo = f"shift+{chr(97 + i)}"
            keyboard.add_hotkey(key_combo, lambda name=b: self.after_idle(self.set_last_bloon, name))
        
        self.update_position()

    # --- Window Movement Logic ---
    def start_drag(self, event):
        self.is_interacting = True
        self.drag_start_x = event.x_root
        self.drag_start_y = event.y_root
        self.window_start_x = self.winfo_x()
        self.window_start_y = self.winfo_y()

    def drag(self, event):
        delta_x = event.x_root - self.drag_start_x
        delta_y = event.y_root - self.drag_start_y
        new_x = self.window_start_x + delta_x
        new_y = self.window_start_y + delta_y
        
        # Recalculate offset relative to game window dynamically while dragging
        hwnd = win32gui.FindWindow(None, "Bloons TD Battles")
        if hwnd:
            rect = win32gui.GetWindowRect(hwnd)
            self.offset_x = new_x - rect[0]
            self.offset_y = new_y - rect[1]
            
        self.geometry(f"{self.current_width}x{self.current_height}+{new_x}+{new_y}")

    # --- Window Resize Logic ---
    def start_resize(self, event):
        self.is_interacting = True
        self.resize_start_x = event.x_root
        self.resize_start_y = event.y_root
        self.window_start_width = self.winfo_width()
        self.window_start_height = self.winfo_height()

    def resize(self, event):
        delta_x = event.x_root - self.resize_start_x
        delta_y = event.y_root - self.resize_start_y
        
        self.current_width = max(200, self.window_start_width + delta_x)
        self.current_height = max(300, self.window_start_height + delta_y)
        
        self.geometry(f"{self.current_width}x{self.current_height}+{self.winfo_x()}+{self.winfo_y()}")

    def stop_interaction(self, event):
        self.is_interacting = False
        # Recalculate text bounds immediately after manual resize release
        self.adjust_window_to_text()

    # --- Gameplay Functions ---
    def toggle_hud(self):
        self.hud_enabled = not self.hud_enabled
        self.update_position()

    def toggle_auto_round(self):
        if not is_game_focused():
            return
        self.auto_round_status = not self.auto_round_status
        self.update_ui_text()
        
    def toggle_camo(self):
        if not is_game_focused():
            return
        self.camo_status = not self.camo_status
        self.update_ui_text()

    def toggle_regen(self):
        if not is_game_focused():
            return
        self.regen_status = not self.regen_status
        self.update_ui_text()

    def toggle_auto_send(self):
        if not is_game_focused():
            return
        self.auto_send_status = not self.auto_send_status
        self.update_ui_text()

    def set_last_bloon(self, bloon):
        if not is_game_focused():
            return
        self.last_bloon = bloon
        self.update_ui_text()

    def trigger_last_bloon(self):
        if not is_game_focused():
            return
        if not self.auto_send_status:
            self.auto_send_status = True
        self.update_ui_text()

    def adjust_window_to_text(self):
        """Forces Tkinter to calculate rendering bounds and resizes the window dynamically."""
        if self.is_interacting:
            return
        self.update_idletasks()
        # Add slight padding constants to ensure bounds completely enclose typography elements
        self.current_width = self.label.winfo_reqwidth() + 15
        self.current_height = self.label.winfo_reqheight() + 15

    def update_ui_text(self):
        auto_status = "ENABLED" if self.auto_round_status else "DISABLED"
        camo = "ON" if self.camo_status else "OFF"
        regen = "ON" if self.regen_status else "OFF"
        send_status = "ENABLED" if self.auto_send_status else "DISABLED"
        
        ui_text = "--- BLOONS TERMINATOR HUD ---\n"
        ui_text += f"Auto-Round: {auto_status}\n"
        ui_text += f"Camo: {camo} | Regen: {regen}\n"
        ui_text += f"Auto-Send: {send_status}\n"
        ui_text += f"Last Sent: {self.last_bloon}\n\n"
        
        ui_text += "HOW TO AUTO-SEND:\n"
        ui_text += "1. Shift + Letter: Set your active Bloon\n"
        ui_text += "2. CTRL+SPACE: Toggle Auto-Send on/off\n"
        ui_text += "3. SHIFT+SPACE: Macro fire last active Bloon From Bloon Send Hotkeys\n\n"
        
        ui_text += "F1: Toggle HUD | UP: Start Round\n"
        ui_text += "DOWN: Toggle Auto-Round\n"
        ui_text += "LEFT: Toggle Camo | RIGHT: Toggle Regen\n"
        ui_text += "CTRL+SPACE: Toggle Auto-Send\n"
        ui_text += "SHIFT+SPACE: Send Last Bloon\n\n"
        ui_text += "BLOON SEND HOTKEYS (Shift + Key):\n"
        
        bloons = ["Red", "BlueSpaced", "BlueGrouped", "Green", "Yellow", "PinkSpaced", "PinkGrouped", "BlackSpaced", "BlackGrouped", "WhiteSpaced", "WhiteGrouped", "LeadSpaced", "LeadGrouped", "ZebraSpaced", "ZebraGrouped", "RainbowSpaced", "RainbowGrouped", "Ceramic", "MOAB", "BFB", "ZOMG"]
        for i, b in enumerate(bloons):
            ui_text += f"Shift+{chr(97 + i)}: {b}\n"
            
        self.label.config(text=ui_text)
        self.adjust_window_to_text()

    def update_position(self):
        hwnd = win32gui.FindWindow(None, "Bloons TD Battles")
        if hwnd:
            rect = win32gui.GetWindowRect(hwnd)
            
            if self.first_track:
                self.offset_x = 0
                self.offset_y = 0
                self.first_track = False
            
            if not self.is_interacting:
                target_x = rect[0] + self.offset_x
                target_y = rect[1] + self.offset_y
                
                # --- Visibility / Offscreen Push-Back Checks ---
                screen_width = self.winfo_screenwidth()
                screen_height = self.winfo_screenheight()
                
                # If window width goes past right boundary edge, push it left
                if target_x + self.current_width > screen_width:
                    target_x = screen_width - self.current_width
                if target_x < 0:
                    target_x = 0
                    
                # If window height goes past bottom boundary edge, push it up
                if target_y + self.current_height > screen_height:
                    target_y = screen_height - self.current_height
                if target_y < 0:
                    target_y = 0
                
                self.geometry(f"{self.current_width}x{self.current_height}+{target_x}+{target_y}")
            
            if self.hud_enabled:
                if not self.winfo_ismapped():
                    self.deiconify()
            else:
                if self.winfo_ismapped():
                    self.withdraw()
        else:
            self.first_track = True  
            if self.winfo_ismapped():
                self.withdraw()
            
        self.after(500, self.update_position)

if __name__ == "__main__":
    app = Overlay()
    app.mainloop()