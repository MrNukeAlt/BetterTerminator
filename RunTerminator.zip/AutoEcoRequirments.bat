@echo off
echo Installing requirements for AutoEco.py...
echo.
:: Upgrade pip to ensure the latest version is used
python -m pip install --upgrade pip

:: Install the required libraries
python -m pip install keyboard pydirectinput

echo.
echo ==================================================
echo Installation complete! 
echo You can now run your script.
echo ==================================================
pause